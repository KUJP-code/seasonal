# frozen_string_literal: true

# Controller for the login splash
class SplashesController < ApplicationController
  def landing; end
end
