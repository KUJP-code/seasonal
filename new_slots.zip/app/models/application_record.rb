# frozen_string_literal: true

# Holds methods for every model
class ApplicationRecord < ActiveRecord::Base
  primary_abstract_class
end
