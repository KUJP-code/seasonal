Oj.optimize_rails()
